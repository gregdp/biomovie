

# LICENCE - please see: https://opensource.org/licenses/MIT

# for development and quick copy/paste as you are writing the script
#    import biomovie; import biomovie.biomovie; biomovie.biomovie.show_dialog()
#    reload(biomovie.biomovie); biomovie.biomovie.show_dialog()
#    execfile ("/Users/greg/Dropbox/_data/biomovie tutorial 2/_movie.py")



# Biomovie Tutorial 2 - A second movie adding some more actions:
# --------------------------------------------------------------
# - SetView, ToView - set and interpolate between vies
# - ModInterp - interpolate model conformation
# - SetDisp - change display of a model
# - RockAts - rock around selected atoms
#--------------------------------------------------
# See Instructions at the bottom to run the script


from biomovie import biomovie as bm


# this gets the BioMovie dialog which helps setup and run the movie
# - it has to be running already, start it from Tools -> Utilities -> BioMovie
dlg = bm.get_dialog()


# this is the movie script
def bioMovieScript () :

    print "Starting movie script..."

    # First, get the models that will be used in the script
    # - these models should be already open in Chimera
    # - the name passed to the function should be the same as what is shown in
    #   the Model Panel

    wholeMap = dlg.GetMod("emd_21452_ex.mrc")
    mapForChain = {}
    for ci in ["A", "B", "C"] :
        mapForChain[ci] = dlg.GetMod("emd_21452_ex_%s.mrc" % ci)

    mol = dlg.GetMod("6vxx.pdb")
    molClosed = dlg.GetMod("6vxx_closed.pdb")
    molOpen = dlg.GetMod("6vxx_open.pdb")


    # A list of models for convenience
    all = [wholeMap] + mapForChain.values() + [molClosed, molOpen, mol]

    print " - done getting models"


    # make the movie object in which actions will be added
    # also makes it the 'active' movie that all actions below will be added to
    movie = bm.Movie(dlg)

    # this sets how many frames per 'second' (where second is what d below is)
    # use 30 for making movie, lower number to speed playback while testing
    frameMul = 30


    # t: time at, d: how long this action will take
    t = 0; d = 0;

    bm.Hide (t, all )
    bm.Show (t, mapForChain.values() )

    # this sets the molecule back to closed state
    bm.ModInterp (t, t, mol, molClosed, molClosed )

    # set display mode to 'ribbon'; in case it is set to surface below
    bm.SetDisp ( t+d, mol, ["ribbon"] )

    # Set to 'side' view; set views in the BioMovie dialog by moving
    # models, entering a view name, pressing the 'Save View' button
    bm.SetView (t, all, 'side' )

    # make chain/protein maps appear
    t += d; d = 1 * frameMul;
    bm.Show (t, mapForChain.values() )
    bm.VaryThr (t, t+d, mapForChain.values(), 3.0, 0.65 )
    bm.SetAlpha (t, mapForChain.values(), 1 )

    # rotate around y-axis
    t += d; d = 6 * frameMul;
    bm.Rotate (t, t+d, all, wholeMap, wholeMap.comPt, [0,1,0], 360.0)

    # Interpolate to 'top' view; also fade out and hide maps
    t += d; d = 2 * frameMul;
    bm.Show (t, mol )
    bm.ToView (t, t+d, all, 'top' )
    bm.VaryAlpha (t, t+d, mapForChain.values(), 1.0, 0.0 )
    bm.Hide (t+d, mapForChain.values() )

    # set display mode to molecular surface
    # - note this will slow down this part of the movie, uncomment it when ready
    # - the surface is a 'density' map with parameters given as:
    #     resolution = 5
    #     grid spacing 1
    #     threshold 0.3
    t += d; d = 1 * frameMul;
    #bm.SetDisp ( t, mol, ["surf", 5, 1, 0.3] )

    # interpolate model from closed to open state
    t += d; d = 1 * frameMul;
    bm.ModInterp (t, t+d, mol, molClosed, molOpen )

    # Interpolate to 'mid' view; make chain B surface transparent
    t += d; d = 2 * frameMul;
    bm.ToView (t, t+d, all, 'mid' )
    bm.VaryAlpha (t, t+d, mol, 1.0, 0.2 )

    # rock using the receptor binding domain as center point
    t += d; d = 6 * frameMul;
    selStr = "#%d:338-529.B" % mol.mod.id
    #MOVIE.add ( ShowSideChains ( t, selStr ) )
    bm.RockAts (t, t+d, all, mapForChain['B'], selStr, [0,1,0], 30.0, 2.0)

    # Interpolate back to 'side' view
    t += d; d = 2 * frameMul;
    bm.ToView (t, t+d, all, 'side' )
    bm.VaryAlpha (t, t+d, mol, 0.4, 1.0 )

    # rotate around y-axis
    t += d; d = 6 * frameMul;
    bm.Rotate (t, t+d, all, wholeMap, wholeMap.comPt, [0,-1,0], 360.0)

    # as a final move, interpolate model from open to closed state
    t += d; d = 1 * frameMul;
    bm.ModInterp (t, t+d, mol, molOpen, molClosed )


    # once all actions have been added, make the movie
    movie.make()





if dlg == None :
    print " - did not find BioMovie dialog"
    print " - start it from Tools -> Utilities -> BioMovie"


else :
    print " - found BioMovie dialog"

    # set the script function in the dialog
    dlg.scriptFun = bioMovieScript

    print " - movie script set; now press 'Go' in the BioMovie dialog"


    # Edit the below with specifics of your movie and folders
    # -------------------------------------------------------

    # set the name of the movie file
    dlg.movieName.set("CoV-2 movie 2")

    # set where frames for the movie will be saved
    dlg.framesPath = "/Users/greg/Dropbox/_data/biomovie tutorial 2/frames"

    # path to ffmpeg, to encode the movie
    #  - the one bundled with Chimera will be used if None is specified
    dlg.ffmpegPath = None




# A list of Actions and their parameters
# --------------------------------------

# Hide (time, model/s )
# - time: time
# - model/s: a single model (of type AnimatableModel) or a list of models

# Show (time, model/s )
# - time: time
# - model/s: a single model (of type AnimatableModel) or a list of models

# SetAlpha (time, model/s, alpha )
# - time: time
# - model/s: a single model (of type AnimatableModel) or a list of models
# - alpha: the transparency, a number between 0 and 1

# VaryAlpha (startTime, endTime, model/s, startAlpha, endAlpha )
# - startTime: startTime
# - endTime: endTime
# - model/s: a single model (of type AnimatableModel) or a list of models
# - startAlpha: start transparency value
# - endAlpha: end transparency value

# SetThr (time, model/s, threshold )
# set threshold
# - time: time
# - model/s: a single model (of type AnimatableModel) or a list of models
# - threshold: the density value at which to draw the isocontour
#   see Volume Viewer for a range of values for any given map
#   be careful with this value, just as when setting the threshold in Chimera
#   using the histogram; too low of a value will show a box around the entire
#   map and can take a long time to refresh the window

# VaryThr (startTime, endTime, model/s, startThr, endThr )
# vary threshold
# - startTime: startTime
# - endTime: endTime
# - model/s: a single model (of type AnimatableModel) or a list of models
# - startThr: start threshold value
# - endThr: end threshold value

# Rotate (startTime, endTime, models, refModel, rotCeterPt, rotAxis,
#         totDegrees, atype="cubic" )
# - startTime: startTime
# - endTime: endTime
# - models: a list of models (of type AnimatableModel)
# - refModel: a reference model - which model to use as a reference; its
#             transform at the start time will be applied to the rotation
#             center point which is in local coordinates
# - rotCeterPt: rotation center point; usually the center of a map/model; this
#             is given in local coordinate as it would be harder to know where
#             it will be before the movie
# - rotAxis: rotation axis
# - totDegrees: how many degrees to rotate by
# - atype: can be cubic or linear; cubic has a smoother start and end

# SetView (time, models, viewName )
# sets a new view
# - time: time
# - models: a list of models
# - viewName: name of view; this has to be set with the BioMovie dialog

# ToView (startTime, endTime, models, viewName, atype="cubic")
# smoothly interpolates to view from wherever the models are
# - startTime: startTime
# - endTime: endTime
# - models: a list of models this will affect
# - viewName: name of view; this has to be set with the BioMovie dialog
# - atype: can be cubic or linear; cubic has a smoother start and end

# RockAts (startTime, endTime, models, refModel, selStr, rotAxis, deg, numCyc, atype="cubic")
# - startTime: startTime
# - endTime: endTime
# - models: a list of models this will affect
# - refModel: which model to use as a reference; its transform at the start time
#             will be applied to the center of the selected atoms which is in
#             local coordinates
# - selStr : a selection string following Chimera's selection syntax
# - rotAxis: rotation axis
# - deg: how many degrees to each side
# - numCyc: number of cycles
# - atype: can be cubic or linear; cubic has a smoother start and end


# ModInterp (t, t+d, mol, molFrom, molTo )
# - startTime: startTime
# - endTime: endTime
# - mol: model to interpolate
# - molFrom: model to interpolate from
# - molTo: model to interpolate to; note that mol, molFrom, molTo should have
#          the same chains/residues/atoms




# Instructions:
# -------------
# 1. open all models in the tutorial folder and set colors as desired
# 2. open the BioMovie dialog from Tools -> Utilities -> BioMovie
# 3. open IDLE from Tools -> General Controls -> IDLE
# 4. in IDLE, run 'execfile ("[path to this script]")'. You should see:
#    - found BioMovie dialog
#    - movie script set; now press 'Go' in the BioMovie dialog
# 5. press the Go buton in the BioMovie dialog
#     - check 'Save' first when ready to make the the movie
#     - before that, make sure to set the framesPath variable above; this is
#       where frames are saved before they are combined into a movie
#     - check 'Stop' at any point to stop if needed
#     - once all frames are recorded, if 'Save' is checked, ffmpeg will then be
#       used to create the movie file in framesPath/../[movie name].mov;
#       this file will be pretty big, but it retains very good quality; to
#       reduce the file size, a program like HandBrake can then be used


# other notes:
# - the movie will have the same dimension as the main Chimera window
# - to set the size of the window to a standard format before making the movie:
# - open the command linefrom Tools -> General Controls -> Command Line
# - in the command line (not in IDLE), run, e.g: 'windowsize 1920 1080'
